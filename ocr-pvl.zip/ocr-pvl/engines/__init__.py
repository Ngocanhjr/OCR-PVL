"""OCR/parser engine modules."""
